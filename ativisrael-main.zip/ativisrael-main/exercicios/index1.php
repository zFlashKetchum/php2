<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificador de Sinal</title>
</head>
<body>
    <h1>Verificador de Sinal</h1>
    <p>Digite um número para verificar se é positivo, negativo ou igual a zero:</p>
    <form action="ativ1.php" method="post">
        <input type="number" name="n1" required>
        <button type="submit">Verificar</button>
    </form>
    
</body>
</html>