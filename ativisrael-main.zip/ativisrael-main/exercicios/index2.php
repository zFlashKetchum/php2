<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificador de Par ou Ímpar</title>
</head>
<body>
    <h1>Verificador de Par ou Ímpar</h1>
    <p>Digite um número para descobrir se é par ou ímpar:</p>
    <form action="ativ2.php" method="post">
        <input type="number" name="numero" required>
        <button type="submit">Verificar</button>
    </form>
</body>
</html> 