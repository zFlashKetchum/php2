<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Triângulo</title>
</head>
<body>
    <h1>Verificação de Triângulo</h1>
    <form action="ativ4.php" method="post">
        <label for="n1">Lado 1:</label>
        <input type="number" id="n1" name="n1" required><br><br>

        <label for="n2">Lado 2:</label>
        <input type="number" id="n2" name="n2" required><br><br>

        <label for="n3">Lado 3:</label>
        <input type="number" id="n3" name="n3" required><br><br>

        <button type="submit">Verificar</button>
    </form>
</body>
</html>