<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Variáveis</title>
</head>
<body>
    <h1>Verificação de Variáveis</h1>
    <form action="ativ3.php" method="post">
        <label for="A">Valor de A:</label>
        <input type="number" id="A" name="n1" required><br><br>
        
        <label for="valorB">Valor de B:</label>
        <input type="number" id="B" name="n2" required><br><br>

        <button type="submit">Verificar</button>
    </form>
    <br>

    <p id="resultado">
       
    </p>
</body>
</html>